package com.example.initial_screen;

import android.support.test.runner.AndroidJUnit4;
import android.util.Log;

import com.android.volley.Response;
import com.example.initial_screen.Activities.LogIn;
import com.example.initial_screen.Activities.MainActivity;
import com.example.initial_screen.R;
import com.example.initial_screen.Requests.LogInRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.mockito.ArgumentMatchers.matches;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.filters.LargeTest;
import androidx.test.rule.ActivityTestRule;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;




@RunWith(AndroidJUnit4.class)
@LargeTest
public class HttpRequestsTesting {

    public static final String NAME = "Steve";


    /**
     * A JUnit {@link Rule @Rule} to launch your activity under test. This is a replacement
     * for {@link android.test.ActivityInstrumentationTestCase2}.
     * <p>
     * Rules are interceptors which are executed for each test method and will run before
     * any of your setup code in the {@link Before @Before} method.
     * <p>
     * {@link ActivityTestRule} will create and launch of the activity for you and also expose
     * the activity under test. To get a reference to the activity you can use
     * the {@link ActivityTestRule#getActivity()} method.
     */
    @Rule
    public ActivityTestRule<LogIn> mActivityRule = new ActivityTestRule<LogIn>(
            LogIn.class);

    @Test
    public void getResponseTest_returnsTrue() {

        onView(withId(R.id.etUsername)).perform(typeText(NAME));
        onView(withId(R.id.etPassword)).perform(typeText("Norman"));
        onView(withId(R.id.btnLogIn)).perform(click());

        onView(withId(R.id.usernameET)).check(matches(withText(NAME)));
    }

    @Test
    public void getResponseTest_returnsFalse() {
        onView(withId(R.id.etUsername)).perform(typeText(NAME));
        onView(withId(R.id.etPassword)).perform(typeText("Gorman"));
        onView(withId(R.id.btnLogIn)).perform(click());

        onView(withId(R.id.etUsername)).check(matches(withText(NAME)));
    }
}

